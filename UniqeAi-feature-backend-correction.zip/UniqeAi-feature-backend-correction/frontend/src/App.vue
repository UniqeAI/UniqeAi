<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script setup>
// Router will handle the page components
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
@import './style.css';
</style>